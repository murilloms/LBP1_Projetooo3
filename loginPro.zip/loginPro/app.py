from flask import Flask, render_template, session, request, redirect, url_for
from models import sessao
from controllers import login, admin


app = Flask(__name__)
app.register_blueprint(login.blue)
app.register_blueprint(admin.blue)
app.secret_key = 'super secret password'

@app.errorhandler(404)
def page_not_found(error):
    return 'Página não encontrada', 404

@app.errorhandler(401)
def acesso_negado(error):
    return 'Acesso negado!', 401

@app.before_request
def b_request():
    if request.path == '/login':
        return
    if not sessao.existe('nome'):
        return redirect(url_for('login.login'))

@app.after_request
def a_request(response):
    print("TA RODANDO RLX")
    return response
    

@app.route('/')
def index():
    return render_template('index.html', nome=sessao.get('nome'))

if __name__ == '__main__':
    app.run(debug=True)