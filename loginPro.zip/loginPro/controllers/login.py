from flask import Flask, Blueprint, render_template, request, redirect, url_for, flash
from models import sessao
from models import usuarios

blue = Blueprint('login', __name__)

@blue.route('/login', methods=['POST', 'GET']) # type: ignore
def login():
    if request.method == 'GET':
        if not sessao.existe('nome'):
            return render_template('login.html')
        else:
            return redirect(url_for('index'))
    if request.method == 'POST':
        nome = request.form['nome']
        senha = request.form['senha']

        for u in usuarios.usuarios:
            if nome == u.nome and senha == u.senha:
                sessao.atualizar_login('nome', nome)
                sessao.atualizar_login('tipo', u.tipo)
                return redirect(url_for('index'))

        flash('Sua senha e/ou nome de usuário estão incorretos.')
        return redirect(url_for('login.login'))

@blue.route('/logout')
def logout():
    sessao.limpar_login()
    return redirect(url_for('index'))