from flask import Flask, Blueprint, render_template, request, redirect, url_for, abort
from models import sessao

blue = Blueprint('admin', __name__)

@blue.route('/admin')
def site_admin():
    if sessao.get('tipo') != 'admin': abort(401)
    return redirect(url_for('adm.pagadm'))