from flask import session

CAMPOS_LOGIN = ['nome', 'tipo']

def limpar_login():
    for campo in CAMPOS_LOGIN:
        session.pop(campo, None)

def existe(campo):
    return campo in session

def get(campo):
    return session[campo]

def atualizar_login(campo, valor):
    session[campo] = valor
