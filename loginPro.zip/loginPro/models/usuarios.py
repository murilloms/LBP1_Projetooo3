class Usuario:
    def __init__(self, nome, senha, tipo):
        self.nome = nome
        self.senha = senha
        self.tipo = tipo

usuarios = [
    Usuario("admin", 'senha1', 'admin'),
    Usuario("user", 'senha1', 'padrao')
]