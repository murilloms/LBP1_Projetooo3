class Produto:
    def __init__(self, id, nome, preco):
        self.id = id
        self.nome = nome
        self.preco = preco

LISTA_PRODUTOS = [
    Produto(1, 'Abacate', 6),
    Produto(2, 'Laranja', 3),
    Produto(3, 'Ameixa', 4)
]