class Usuario:
    def __init__(self, nome, senha, tipo):
        self.nome = nome
        self.senha = senha
        self.tipo = tipo

USUARIOS = [
    Usuario("chefe", 'senhadochefe', 'admin'),
    Usuario("murillo", 'senhadomurillo', 'padrao')
]