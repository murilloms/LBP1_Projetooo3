from flask import session

CAMPOS_LOGIN = ['nome', 'tipo']

def existe(campo):
    return campo in session

def get(campo):
    return session[campo]

def atualizarlogin(campo, valor):
    session[campo] = valor

def limparlogin():
    for campo in CAMPOS_LOGIN:
        session.pop(campo, None)